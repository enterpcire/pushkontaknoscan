const chalk = require("chalk")
const fs = require("fs")

//owmner v card
global.owner = ['6285770919470'] //ur owner number
global.ownernomer = "6285770919470" //ur owner number2
global.ownername = "MarselStore" //ur owner name
global.ytname = "-" //ur yt chanel name
global.socialm = "-" //ur github or insta name
global.location = "Indonesia" //ur location

//new
global.ownergc = "-"
global.botname = "Created By MarsBotZ"
global.ownerNumber = ["6285770919470@s.whatsapp.net"]
global.ownerweb = "-"
global.themeemoji = '🪀'
global.wm = "xyura.my.id"
global.packname = "Sticker By"
global.author = "MarselStore\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumb = { url: 'https://i.ibb.co/RSqYjS9/20221116-170949.jpg' }//ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//messages
global.mess = {
    selesai: 'Done !!', 
    owner: 'Khusus Owner',
    private: 'Khusus Private',
    group: 'Khusus Group',
    wait: 'Sebentar..',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
